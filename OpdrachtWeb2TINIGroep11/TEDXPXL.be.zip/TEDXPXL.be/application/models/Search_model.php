<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Search_model extends CI_Model {
  function __construct() {
    parent::__construct();
  }

  function get_events($search_string) {
    if ($search_string == null) {
      $query = "SELECT * FROM `events` WHERE DATE(NOW()) < DATE(`datum`) ";
    } else {
      $query = "SELECT * FROM `events` WHERE `naam` LIKE '%".$search_string."%' 
                AND DATE(NOW()) < DATE(`datum`)";
    }

    $result = $this->db->query($query, array($search_string, $search_string));
    if ($result) {
      return $result;
    } else {
      return false;
    }
  }   
}
