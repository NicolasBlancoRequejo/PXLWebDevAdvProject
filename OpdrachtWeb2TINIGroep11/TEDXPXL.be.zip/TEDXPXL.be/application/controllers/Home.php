<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function __construct() {
    parent::__construct();
    $this->load->library('session');
    $this->load->helper('form');
    $this->load->helper('url');
    $this->load->helper('security');
    $this->lang->load('en_admin', 'english'); 
    $this->load->library('form_validation');
    $this->form_validation->set_error_delimiters('<div class="alert alert-warning" role="alert">', '</div>'); 
    $this->load->model('Search_model');


    }
    
    public function index(){
            $page_data['title']="Home Page";

            $this->load->view('common/header',$page_data);
            $this->load->view('nav/top_nav');
            $this->load->view('home/home');
            $this->load->view('common/footer');
    }
        
    public function search(){
        $page_data['title']="Home Page";
        $this->form_validation->set_rules('search_string', $this->lang->line('search_string'), 'required|min_length[1]|max_length[125]');
        $page_data['query'] = $this->Search_model->get_events($this->input->post('search_string'));

        if ($this->form_validation->run() == FALSE) {
          $page_data['search_string'] = array('name' => 'search_string', 'class' => 'form-control', 'id' => 'search_string', 'value' => set_value('search_string', $this->input->post('search_string')), 'maxlength'   => '100', 'size' => '35');

          $page_data['query'] = $this->Search_model->get_events($this->input->post('search_string'));
          $this->load->view('common/header',$page_data);
            $this->load->view('nav/top_nav');
            $this->load->view('home/search');
            $this->load->view('common/footer');
        } else {
          $this->load->view('common/header',$page_data);
          $this->load->view('nav/top_nav');
          $this->load->view('home/search');
          $this->load->view('common/footer');      
        }    

       
    }
   
}