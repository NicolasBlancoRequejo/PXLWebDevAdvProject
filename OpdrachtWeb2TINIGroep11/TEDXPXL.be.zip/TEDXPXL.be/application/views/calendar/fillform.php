<?php 
	  print $naam;
	  print $beginuur;
	  print $einduur;
	  print $commentaar;
?>


