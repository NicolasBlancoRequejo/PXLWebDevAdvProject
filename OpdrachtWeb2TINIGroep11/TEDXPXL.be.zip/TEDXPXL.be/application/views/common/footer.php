    </div>
</div>

        <footer>
                <div class="container">
                        <div class="row">
                                <div class="col-sm-8">
                                        <h6>About</h6>
                                        <p>TEDxPXL is an independently organized TED conference <br />where speakers from around the world share cutting-edge ideas. <br />During the breaks, attendees connect with each other through various interactive activities.</p>
                                </div>

                                <div class="col-sm-2">
                                        <h6>Navigation</h6>
                                        <ul class="unstyled">
                                            <li><a href="<?php echo base_url("home"); ?>">Home</a></li>
                                            <!--<li><a href="#">News</a></li> -->                      
                                            <li><a href="<?php echo base_url("discussions"); ?>">Forum</a></li>                           
                                            <li><a href="<?php echo base_url("mycal/showcal"); ?>">Events</a></li>    
                                            <li><a href="<?php echo base_url("contact"); ?>">Contact</a></li> 
                                        </ul>
                                </div>

                                <div class="col-sm-2">
                                        <h6>Follow us</h6>
                                        <ul class="unstyled">
                                                <li><a href="https://twitter.com/hogeschoolpxl">On Twitter</a></li>
                                                <li><a href="https://www.facebook.com/HogeschoolPXL">On Facebook</a></li>
                                        </ul>
                                </div>
                        </div>
                </div>
        </footer>

  
	<script src="http://code.jquery.com/jquery.js"></script>
	
	<script>window.jQuery || document.write('<script src="includes/js/jquery-1.8.2.min.js"><\/script>')</script>
	
	<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
	

</body>
</html>
