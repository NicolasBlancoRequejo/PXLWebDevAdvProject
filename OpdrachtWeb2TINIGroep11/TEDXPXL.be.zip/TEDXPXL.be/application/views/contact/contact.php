<div id="banner">
    <div class="thumbnails row">
        <div class="thumbnail">
            <div class="caption">
                <h2 style="color: #FF2B06">Contact Information</h2>
                <a><img src="<?php echo base_url('images/pxllogo.png"'); ?>" alt="PXL Logo"></a>
                <p>Hogeschool PXL</p>
                <a href="https://www.google.be/maps/place/Hogeschool+PXL/@50.93735,5.348644,17z/data=!3m1!4b1!4m2!3m1!1s0x47c12177528ced33:0x27d80a1d25c8505?hl=en" target="_blank"><p>Elfde-Liniestraat 24<br/>B-3500 Hasselt</p></a>
                <p><a href="callto://+3211775555">tel. + 32 11 77 55 55</a></p>
                <p>fax. + 32 11 77 55 59</p>
                <p><a href="http://www.pxl.be">www.pxl.be</a></p>
                <p><a href="mailto:pxl@pxl.be">pxl@pxl.be</a></p>
            </div>
        </div>

    </div>
</div>
