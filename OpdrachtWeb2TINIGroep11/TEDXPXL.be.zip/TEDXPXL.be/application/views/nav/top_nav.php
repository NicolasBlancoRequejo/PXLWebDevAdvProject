<body onload="initialize()">
<div class="container" id="main">
        <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        <a class="navbar-brand" href="<?php echo base_url("home"); ?>"><img src="<?php echo base_url('images/logo.png"'); ?>" alt="Your Logo"></a>

        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="<?php echo base_url("home"); ?>">Home</a></li>
            <?php if ($this->session->userdata('logged_in') == TRUE) : ?>
                <li class="dropdown">
                    <a href="" class="dropdown-toggle" data-toggle="dropdown">Forum <strong class="caret"></strong></a>

                    <ul class="dropdown-menu">
                            <li><?php echo anchor(base_url('Discussions'), 'Forum') ; ?></li>

                            <?php if ($this->session->userdata('usr_access_level') == 1) : ?>
                                <li><?php echo anchor(base_url('admin/dashboard'), 'Dashboard') ; ?></li>
                            <?php endif ; ?>
                            <li><?php echo anchor(base_url('Discussions/create'), 'Create discussion') ; ?></li>


                    </ul>
                </li>
            <?php else : ?>
                <li><a href="<?php echo base_url("discussions"); ?>">Forum</a></li>    
            <?php endif ; ?>
            <li><a href="<?php echo base_url("mycal/showcal"); ?>">Events</a></li>
            <li class="active"><a href="<?php echo base_url("contact"); ?>">Contact</a></li>
            <li>
                <div class="search">
                    <h1>
                      <?php echo form_open('home/search') ; ?>
                        <div class="row">
                          <div class="col-lg-12">
                            <div class="input-group">
                              <input type="text" class="form-control" name="search_string" placeholder="Search Events">
                              <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">GO</button>
                              </span>
                            </div><!-- /input-group -->
                          </div><!-- /.col-lg-6 -->
                        </div><!-- /.row -->
                      <?php echo form_close() ; ?>
                    </h1>
                 </div>
            </li>
          </ul>
          
          <ul class="nav navbar-nav navbar-right">
            <?php if ($this->session->userdata('logged_in') == TRUE) : ?>
              <li><?php echo anchor(base_url('me'), 'Profiel') ; ?></li>
              <li><?php echo anchor(base_url('signin/signout'), 'Logout' ); ?></li>
            <?php else : ?>
              <li><?php echo anchor(base_url('signin'), 'Login') ; ?></li>
            <?php endif ; ?>
          </ul>
          <!-- Search functie bestaat nog niet
          <form class="navbar-form pull-left">
            <input type="text" class="form-control" placeholder="Search this site..." id="searchInput">
            <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search"></span></button>
          </form> -->
        </div><!--/.nav-collapse -->
      </div>
    </div>
    <div class="views">