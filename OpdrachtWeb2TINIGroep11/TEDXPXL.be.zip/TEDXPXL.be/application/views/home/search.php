<table class="table table-hover">
  <?php foreach ($query->result() as $row) : ?>
  <tr>
      <td><?php echo $row->naam ; ?><br /><?php echo $row->commentaar ; ?>
    </td>     
      <td>On <?php echo $row->datum?> <br />From <?php echo $row->beginuur ; ?> To <?php echo $row->einduur ; ?> <br />Locatie: <?php echo $row->locatie ; ?>

  </tr>
<?php endforeach ; ?>
</table>