<div id="banner">
    <div class="thumbnails row">
        <div class="thumbnail">
            <img id="bannerImage" alt="tedxpxl banner" src="<?php echo base_url('images/carousel_large_01.jpg"'); ?>">
                <div class="caption">
                        <h2>We're searching for new members!!</h2>

                        <p><a href="<?php echo base_url('register'); ?>" class="btn btn-primary btn-neutral" target="_blank">Become Member</a></p>
                </div>
        </div>

    </div>
</div>
