<?php

class Spark_exception extends Exception {

}
